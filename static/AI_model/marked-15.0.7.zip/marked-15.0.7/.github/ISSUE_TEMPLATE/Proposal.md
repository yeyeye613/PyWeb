---
name: Proposal
about: Marked doesn't do this thing and I think it should

---

**What pain point are you perceiving?.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.
