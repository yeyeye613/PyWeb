see https://github.com/markedjs/marked/releases
