Situations where it fails:

**test 💁**

**💁 test**

**🤓 test**

**🏖️ test**

**🏖️🤓💁 test**

**💁 test** test

test **💁 test**

test **💁 test** test

***test 💁***

***💁 test***

***💁 test*** test

test ***💁 test***

test ***💁 test*** test

****💁 test****

Situations where it works:

**💁 **

**⚠️ test**

Here, the emoji rendering works, but the text doesn't get rendered in italic.

*💁 test*

*t💁t* test

**t💁t** test
