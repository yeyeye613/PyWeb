| a | b |
| - | - |
| 1 | 2 |
| 3 | 4 |
##

No newline at the end

| a | b |
| - | - |
| 1 | 2 |
| 3 | 4 |
##