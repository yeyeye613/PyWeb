![](img1.svg) (or ![](img2.svg))

![one](img1.svg) (or ![two](img2.svg))
