- this is a list, not a heading
-----

1) this is also a list
* it should be a list
- not heading
-----

<s>not heading</s>
- this is also a list, not a multiline heading
*****

[click here](/index.jpg)
- this has to be a list
- true...
_____

<b>heading</b>
-this one is a heading
-----

<b>heading</b> - this is a heading too
-----
