<details>
  
  ## Heading
</details>
  
  ## Heading
<custom-tag>
  
  ## Heading
</custom-tag>
  
  ## Heading
<details>
	
	## Heading
</details>
	
	## Heading
<custom-tag>
	
	## Heading
</custom-tag>
	
	## Heading
