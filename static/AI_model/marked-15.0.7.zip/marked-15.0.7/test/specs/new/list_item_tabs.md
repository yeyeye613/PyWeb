- A
-   B
-	C
-	D
-	E
-	F

1. A
2.   B
3.	C
4.	D
5.	E
6.	F
