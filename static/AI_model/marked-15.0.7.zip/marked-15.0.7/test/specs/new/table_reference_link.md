|   a    |
| ------ |
| [d][c] |

[c]: https://www.google.com
