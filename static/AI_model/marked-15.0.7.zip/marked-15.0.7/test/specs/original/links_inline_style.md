---
pedantic: true
---

Just a [URL](/url/).

[URL and title](/url/ "title").

[URL and title](/url/  "title preceded by two spaces").

[URL and title](/url/	"title preceded by a tab").

[URL and title](/url/ "title has spaces afterward"  ).

[URL and title]( /url/has space ).

[URL and title]( /url/has space/ "url has space and title").

[Empty]().
