module.exports = {
  markdown: '- a\n'.repeat(10000),
  html: `<ul>${'<li>a</li>'.repeat(10000)}</ul>`,
};
