export default {
  breaks: true,
};
